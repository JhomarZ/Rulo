<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Product;

class ProductController extends Controller
{
    //
    public function Detail(Request $request,$id){
        //$product = array('product' => []);

        $product = Product::with("attributes")->find($id);//::where('id', '=', $id)->with("attributes")->first();;

        return response($product, 200)
        ->header('Content-Type', 'application/json')
        ->header('Access-Control-Allow-Origin', '*');
    }

    private function UpdateViews($id){
        //$product = array('product' => []);

        $product=Product::find($id)->with("attributes")->first();

       // Si existe
        if(count($product)>=1){
            // sumamos una nueva visita
            $product->total_saw = ($product->total_saw+1);
            // Guardamos en base de datos
            $product->save();
        }
    }
}
