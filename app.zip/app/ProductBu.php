<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductBu extends Model
{
    //
    protected $table="product_bu";
}
